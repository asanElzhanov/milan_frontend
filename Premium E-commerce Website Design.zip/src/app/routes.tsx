import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { Catalog } from "./pages/Catalog";
import { Product } from "./pages/Product";
import { Cart } from "./pages/Cart";
import { Account } from "./pages/Account";

// Simple placeholders for other routes to ensure they don't break
const Placeholder = ({ title }: { title: string }) => (
  <div className="flex-grow flex items-center justify-center py-32 text-center px-5">
    <div>
      <h1 className="text-4xl font-serif mb-4">{title}</h1>
      <p className="text-sara-graphite/60 text-sm">This page is under construction.</p>
    </div>
  </div>
);

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "catalog", Component: Catalog },
      { path: "product/:id", Component: Product },
      { path: "cart", Component: Cart },
      { path: "account", Component: Account },
      { path: "account/favorites", Component: () => <Account /> }, // Simplification
      { path: "login", Component: () => <Placeholder title="Sign In / Register" /> },
      { path: "checkout", Component: () => <Placeholder title="Secure Checkout" /> },
      { path: "about", Component: () => <Placeholder title="Our Story" /> },
      { path: "delivery", Component: () => <Placeholder title="Delivery & Returns" /> },
      { path: "faq", Component: () => <Placeholder title="Frequently Asked Questions" /> },
      { path: "contacts", Component: () => <Placeholder title="Contact Us" /> },
      { path: "terms", Component: () => <Placeholder title="Terms of Service" /> },
      { path: "privacy", Component: () => <Placeholder title="Privacy Policy" /> },
      { path: "*", Component: () => <Placeholder title="Page Not Found" /> },
    ],
  },
]);