import { Link } from "react-router";
import { Heart } from "lucide-react";
import { useState } from "react";

interface ProductCardProps {
  product: {
    id: string;
    name: string;
    price: number;
    salePrice: number | null;
    image: string;
    hoverImage: string;
    isNew: boolean;
  };
}

export function ProductCard({ product }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="group flex flex-col cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative aspect-[3/4] bg-sara-beige mb-4 overflow-hidden">
        {product.isNew && (
          <span className="absolute top-3 left-3 z-10 bg-sara-white px-2 py-1 text-xs uppercase tracking-wider text-sara-graphite">
            New
          </span>
        )}
        <button className="absolute top-3 right-3 z-10 p-2 opacity-0 group-hover:opacity-100 transition-opacity bg-sara-white/80 rounded-full hover:bg-sara-white">
          <Heart size={18} strokeWidth={1.5} className="text-sara-graphite" />
        </button>
        <Link to={`/product/${product.id}`} className="block w-full h-full">
          <img 
            src={isHovered ? product.hoverImage : product.image} 
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 ease-in-out group-hover:scale-105"
          />
        </Link>
      </div>
      <div className="flex flex-col items-center text-center px-2">
        <Link to={`/product/${product.id}`} className="hover:text-sara-bronze transition-colors">
          <h3 className="font-sans text-sm tracking-wide text-sara-graphite mb-1">{product.name}</h3>
        </Link>
        <div className="flex gap-2 items-center">
          {product.salePrice ? (
            <>
              <span className="text-sm text-sara-bronze font-medium">${product.salePrice}</span>
              <span className="text-xs text-sara-graphite/60 line-through">${product.price}</span>
            </>
          ) : (
            <span className="text-sm text-sara-graphite font-medium">${product.price}</span>
          )}
        </div>
      </div>
    </div>
  );
}