import { Link, Outlet } from "react-router";
import { Search, Heart, User, ShoppingBag, Menu } from "lucide-react";
import { CATEGORIES } from "../data/mockData";

export function Layout() {
  return (
    <div className="min-h-screen flex flex-col font-sans text-sara-graphite bg-sara-white">
      {/* Announcement Bar */}
      <div className="bg-sara-bronze text-white text-xs text-center py-2 tracking-widest uppercase">
        Free worldwide shipping on orders over $500
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-sara-white/95 backdrop-blur-sm border-b border-sara-beige-dark/20">
        <div className="max-w-[1440px] mx-auto px-5 md:px-[80px] h-[80px] flex items-center justify-between">
          
          {/* Mobile Menu & Search (Left) */}
          <div className="flex items-center gap-4 flex-1 md:hidden">
            <button aria-label="Menu" className="p-1"><Menu size={24} strokeWidth={1.5} /></button>
            <button aria-label="Search" className="p-1"><Search size={24} strokeWidth={1.5} /></button>
          </div>

          {/* Desktop Navigation (Left) */}
          <nav className="hidden md:flex items-center gap-8 flex-1">
            {CATEGORIES.slice(0, 4).map((cat) => (
              <Link 
                key={cat.name} 
                to={cat.link}
                className="text-sm uppercase tracking-wider hover:text-sara-bronze transition-colors"
              >
                {cat.name}
              </Link>
            ))}
          </nav>

          {/* Logo (Center) */}
          <div className="flex-shrink-0 flex justify-center flex-1 md:flex-none">
            <Link to="/" className="text-2xl md:text-3xl font-serif tracking-widest text-sara-graphite">
              SARA MILAN
            </Link>
          </div>

          {/* Icons (Right) */}
          <div className="flex items-center justify-end gap-3 md:gap-5 flex-1">
            <button aria-label="Search" className="hidden md:block p-1 hover:text-sara-bronze transition-colors">
              <Search size={22} strokeWidth={1.5} />
            </button>
            <Link to="/account/favorites" aria-label="Favorites" className="hidden md:block p-1 hover:text-sara-bronze transition-colors">
              <Heart size={22} strokeWidth={1.5} />
            </Link>
            <Link to="/login" aria-label="Account" className="p-1 hover:text-sara-bronze transition-colors">
              <User size={22} strokeWidth={1.5} />
            </Link>
            <Link to="/cart" aria-label="Cart" className="p-1 hover:text-sara-bronze transition-colors relative">
              <ShoppingBag size={22} strokeWidth={1.5} />
              <span className="absolute -top-1 -right-1 bg-sara-bronze text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                2
              </span>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow flex flex-col">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-sara-graphite text-sara-white pt-20 pb-10 mt-auto">
        <div className="max-w-[1440px] mx-auto px-5 md:px-[80px]">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-8 mb-16">
            <div className="col-span-1 md:col-span-1">
              <Link to="/" className="text-2xl font-serif tracking-widest mb-6 block">
                SARA MILAN
              </Link>
              <p className="text-sara-beige/70 text-sm leading-relaxed mb-6">
                Premium women's footwear and accessories, crafted with uncompromising quality and timeless elegance.
              </p>
            </div>
            
            <div>
              <h4 className="text-sm uppercase tracking-wider mb-6 font-medium">Shop</h4>
              <ul className="space-y-4 text-sm text-sara-beige/70">
                <li><Link to="/catalog" className="hover:text-white transition-colors">New In</Link></li>
                <li><Link to="/catalog" className="hover:text-white transition-colors">Shoes</Link></li>
                <li><Link to="/catalog" className="hover:text-white transition-colors">Bags</Link></li>
                <li><Link to="/catalog" className="hover:text-white transition-colors">Accessories</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="text-sm uppercase tracking-wider mb-6 font-medium">Customer Care</h4>
              <ul className="space-y-4 text-sm text-sara-beige/70">
                <li><Link to="/delivery" className="hover:text-white transition-colors">Delivery & Returns</Link></li>
                <li><Link to="/faq" className="hover:text-white transition-colors">FAQ</Link></li>
                <li><Link to="/contacts" className="hover:text-white transition-colors">Contact Us</Link></li>
                <li><Link to="/account" className="hover:text-white transition-colors">My Account</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="text-sm uppercase tracking-wider mb-6 font-medium">Newsletter</h4>
              <p className="text-sara-beige/70 text-sm mb-4">Subscribe to receive updates, access to exclusive deals, and more.</p>
              <form className="flex border-b border-sara-beige/30 pb-2 focus-within:border-white transition-colors">
                <input 
                  type="email" 
                  placeholder="Enter your email address" 
                  className="bg-transparent border-none outline-none flex-grow text-sm text-white placeholder:text-sara-beige/50"
                />
                <button type="submit" className="text-xs uppercase tracking-wider hover:text-sara-bronze transition-colors">Subscribe</button>
              </form>
            </div>
          </div>
          
          <div className="border-t border-sara-beige/20 pt-8 flex flex-col md:flex-row items-center justify-between text-xs text-sara-beige/50">
            <p>&copy; {new Date().getFullYear()} SARA MILAN. All rights reserved.</p>
            <div className="flex gap-4 mt-4 md:mt-0">
              <Link to="/terms" className="hover:text-white transition-colors">Terms of Service</Link>
              <Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}