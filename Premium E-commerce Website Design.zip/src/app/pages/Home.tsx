import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import { ProductCard } from "../components/ProductCard";
import { MOCK_PRODUCTS } from "../data/mockData";

export function Home() {
  const newArrivals = MOCK_PRODUCTS.filter(p => p.isNew);
  const bestSellers = MOCK_PRODUCTS.filter(p => p.isBestseller);

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[85vh] w-full flex items-center justify-center overflow-hidden bg-sara-beige">
        <img 
          src="https://images.unsplash.com/photo-1714636608872-048fc9231892?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwcGhvdG9ncmFwaHklMjBiZWlnZSUyMGFlc3RoZXRpY3N8ZW58MXx8fHwxNzgwMDQ4MDk3fDA&ixlib=rb-4.1.0&q=80&w=2000" 
          alt="Sara Milan New Collection" 
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-black/20" /> {/* Slight overlay for text readability */}
        
        <div className="relative z-10 text-center px-5 flex flex-col items-center">
          <h2 className="text-sm md:text-base uppercase tracking-[0.3em] text-white mb-4">Fall / Winter 2026</h2>
          <h1 className="text-4xl md:text-7xl font-serif text-white mb-8 max-w-3xl leading-tight">
            The Essence of Modern Elegance
          </h1>
          <Link 
            to="/catalog" 
            className="inline-block bg-white text-sara-graphite px-10 py-4 text-sm uppercase tracking-widest hover:bg-sara-bronze hover:text-white transition-colors duration-300"
          >
            Shop Collection
          </Link>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-20 md:py-32 px-5 md:px-[80px] max-w-[1440px] mx-auto w-full">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { title: "Boots", image: "https://images.unsplash.com/photo-1531310197839-ccf54634509e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwbGVhdGhlciUyMGJvb3RzJTIwd29tZW58ZW58MXx8fHwxNzgwMDQ4MDk3fDA&ixlib=rb-4.1.0&q=80&w=800" },
            { title: "Pumps", image: "https://images.unsplash.com/photo-1535043934128-cf0b28d52f95?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwaGVlbHMlMjBmYXNoaW9ufGVufDF8fHx8MTc4MDA0ODA5N3ww&ixlib=rb-4.1.0&q=80&w=800" },
            { title: "Accessories", image: "https://images.unsplash.com/photo-1586878341523-7acb55eb8c12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21lbiUyMGFjY2Vzc29yaWVzJTIwcHJlbWl1bXxlbnwxfHx8fDE3ODAwNDgwOTd8MA&ixlib=rb-4.1.0&q=80&w=800" }
          ].map((cat) => (
            <Link key={cat.title} to="/catalog" className="group relative aspect-[3/4] overflow-hidden bg-sara-beige block">
              <img src={cat.image} alt={cat.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-black/10 group-hover:bg-black/20 transition-colors duration-300" />
              <div className="absolute bottom-8 left-0 w-full text-center">
                <h3 className="text-white text-2xl font-serif mb-2">{cat.title}</h3>
                <span className="text-white text-xs uppercase tracking-widest inline-flex items-center gap-2">
                  Discover <ArrowRight size={14} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* New Collection */}
      <section className="py-20 bg-sara-beige/30">
        <div className="max-w-[1440px] mx-auto px-5 md:px-[80px]">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-serif mb-3">New Arrivals</h2>
              <p className="text-sara-graphite/60 text-sm">Discover the latest additions to our collection.</p>
            </div>
            <Link to="/catalog" className="hidden md:inline-flex items-center gap-2 text-sm uppercase tracking-widest hover:text-sara-bronze transition-colors">
              View All <ArrowRight size={16} />
            </Link>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {newArrivals.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          
          <div className="mt-10 text-center md:hidden">
            <Link to="/catalog" className="inline-flex items-center gap-2 text-sm uppercase tracking-widest border-b border-sara-graphite pb-1">
              View All
            </Link>
          </div>
        </div>
      </section>

      {/* Brand Story / Lookbook Promo */}
      <section className="py-20 md:py-32">
        <div className="max-w-[1440px] mx-auto px-5 md:px-[80px] flex flex-col md:flex-row items-center gap-12 md:gap-24">
          <div className="flex-1 w-full relative aspect-[4/5] md:aspect-square">
            <img 
              src="https://images.unsplash.com/photo-1543163521-1bf539c55dd2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB3b21lbiUyMHNob2VzJTIwc3R5bGluZ3xlbnwxfHx8fDE3ODAwNDgwOTZ8MA&ixlib=rb-4.1.0&q=80&w=1200" 
              alt="Craftsmanship" 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex-1">
            <h3 className="text-xs uppercase tracking-[0.2em] text-sara-bronze mb-4">Our Heritage</h3>
            <h2 className="text-3xl md:text-5xl font-serif mb-6 leading-tight">Uncompromising Quality & Design</h2>
            <p className="text-sara-graphite/70 mb-8 leading-relaxed">
              At Sara Milan, we believe that true luxury lies in the details. Every pair of shoes is meticulously crafted using the finest materials, blending timeless elegance with modern comfort. Our designs are created for the sophisticated woman who appreciates both style and substance.
            </p>
            <Link 
              to="/about" 
              className="inline-block border border-sara-graphite px-8 py-3 text-sm uppercase tracking-widest hover:bg-sara-graphite hover:text-white transition-colors duration-300"
            >
              Read Our Story
            </Link>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="border-t border-b border-sara-beige-dark/20 bg-sara-white">
        <div className="max-w-[1440px] mx-auto px-5 md:px-[80px] py-16">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-sara-beige-dark/20">
            {[
              { title: "Premium Materials", desc: "Finest Italian leather and suede" },
              { title: "Free Shipping", desc: "On all orders over $500" },
              { title: "Easy Returns", desc: "14-day return policy" },
              { title: "Secure Payment", desc: "100% secure checkout" }
            ].map((benefit, i) => (
              <div key={i} className={`pt-8 md:pt-0 ${i === 0 ? '' : 'md:pl-8'}`}>
                <h4 className="font-serif text-lg mb-2">{benefit.title}</h4>
                <p className="text-sm text-sara-graphite/60">{benefit.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}