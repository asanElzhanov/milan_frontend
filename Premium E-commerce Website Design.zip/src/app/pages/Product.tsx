import { useState } from "react";
import { useParams, Link } from "react-router";
import { Heart, ChevronRight, Truck, RefreshCw, MessageCircle } from "lucide-react";
import { MOCK_PRODUCTS } from "../data/mockData";
import { ProductCard } from "../components/ProductCard";

export function Product() {
  const { id } = useParams();
  const product = MOCK_PRODUCTS.find(p => p.id === id) || MOCK_PRODUCTS[0];
  
  const [selectedSize, setSelectedSize] = useState<number | string | null>(null);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);

  return (
    <div className="flex flex-col flex-grow">
      {/* Breadcrumbs */}
      <div className="max-w-[1440px] mx-auto w-full px-5 md:px-[80px] py-6 flex items-center gap-2 text-xs text-sara-graphite/50 uppercase tracking-wider">
        <Link to="/" className="hover:text-sara-graphite transition-colors">Home</Link>
        <ChevronRight size={12} />
        <Link to="/catalog" className="hover:text-sara-graphite transition-colors">Shoes</Link>
        <ChevronRight size={12} />
        <span className="text-sara-graphite">{product.name}</span>
      </div>

      <div className="max-w-[1440px] mx-auto w-full px-5 md:px-[80px] pb-20 flex flex-col md:flex-row gap-10 md:gap-20">
        
        {/* Image Gallery */}
        <div className="flex-1 grid grid-cols-2 gap-4 h-fit">
          <div className="col-span-2">
            <img src={product.image} alt={product.name} className="w-full object-cover bg-sara-beige" />
          </div>
          <img src={product.hoverImage} alt={`${product.name} detail`} className="w-full object-cover bg-sara-beige" />
          <img src={product.image} alt={`${product.name} back`} className="w-full object-cover bg-sara-beige" />
        </div>

        {/* Product Info */}
        <div className="flex-1 md:max-w-[480px]">
          <div className="sticky top-[120px]">
            <h1 className="text-3xl md:text-4xl font-serif mb-4">{product.name}</h1>
            <div className="text-xl mb-8">
              {product.salePrice ? (
                <div className="flex items-center gap-4">
                  <span className="text-sara-bronze font-medium">${product.salePrice}</span>
                  <span className="text-sara-graphite/40 line-through">${product.price}</span>
                </div>
              ) : (
                <span>${product.price}</span>
              )}
            </div>

            {/* Colors */}
            <div className="mb-8">
              <div className="flex justify-between items-center mb-3">
                <span className="text-sm uppercase tracking-wider">Color: <span className="text-sara-graphite/60">{selectedColor}</span></span>
              </div>
              <div className="flex gap-3">
                {product.colors.map(color => (
                  <button 
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`w-8 h-8 rounded-full border-2 ${selectedColor === color ? 'border-sara-graphite' : 'border-transparent'} flex items-center justify-center p-[2px]`}
                  >
                    <div className="w-full h-full rounded-full" style={{ backgroundColor: color.toLowerCase() === 'black' ? '#000' : color.toLowerCase() === 'brown' ? '#8B4513' : color.toLowerCase() === 'tan' ? '#D2B48C' : '#F5F5DC' }} />
                  </button>
                ))}
              </div>
            </div>

            {/* Sizes */}
            <div className="mb-10">
              <div className="flex justify-between items-center mb-3">
                <span className="text-sm uppercase tracking-wider">Size</span>
                <button className="text-xs text-sara-graphite/60 underline hover:text-sara-graphite transition-colors">Size Guide</button>
              </div>
              <div className="grid grid-cols-4 gap-3">
                {product.sizes.map(size => (
                  <button 
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`border py-3 text-sm transition-colors ${selectedSize === size ? 'border-sara-graphite bg-sara-graphite text-white' : 'border-sara-beige-dark/50 hover:border-sara-graphite'}`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col gap-3 mb-10">
              <button className="w-full bg-sara-graphite text-white py-4 text-sm uppercase tracking-widest hover:bg-black transition-colors">
                Add to Cart
              </button>
              <div className="flex gap-3">
                <button className="flex-1 border border-sara-graphite py-4 text-sm uppercase tracking-widest hover:bg-sara-beige transition-colors">
                  Buy Now
                </button>
                <button className="border border-sara-beige-dark/50 p-4 hover:border-sara-graphite transition-colors flex items-center justify-center">
                  <Heart size={20} strokeWidth={1.5} />
                </button>
              </div>
              <button className="w-full flex items-center justify-center gap-2 text-sm text-[#25D366] border border-[#25D366] py-3 hover:bg-[#25D366]/10 transition-colors mt-2">
                <MessageCircle size={18} /> Order via WhatsApp
              </button>
            </div>

            {/* Details Accordion (Simplified) */}
            <div className="border-t border-sara-beige-dark/20 divide-y divide-sara-beige-dark/20">
              <div className="py-5">
                <h3 className="font-serif text-lg mb-3">Description</h3>
                <p className="text-sm text-sara-graphite/70 leading-relaxed">
                  Crafted in Italy from butter-soft leather, these {product.name.toLowerCase()} are a testament to timeless design. Featuring a sleek silhouette and comfortable block heel, they are perfect for transitioning from day to night with effortless elegance.
                </p>
              </div>
              <div className="py-5">
                <h3 className="font-serif text-lg mb-3">Materials & Care</h3>
                <ul className="text-sm text-sara-graphite/70 list-disc pl-4 space-y-1">
                  <li>100% Italian Leather</li>
                  <li>Leather lining and sole</li>
                  <li>Wipe clean with a soft, dry cloth</li>
                  <li>Store in the provided dust bag</li>
                </ul>
              </div>
              <div className="py-5 flex flex-col gap-4 text-sm text-sara-graphite/80">
                <div className="flex items-center gap-3"><Truck size={18} strokeWidth={1.5} className="text-sara-bronze" /> <span>Free express delivery on orders over $500</span></div>
                <div className="flex items-center gap-3"><RefreshCw size={18} strokeWidth={1.5} className="text-sara-bronze" /> <span>14-day free returns policy</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      <section className="bg-sara-beige/30 py-20">
        <div className="max-w-[1440px] mx-auto px-5 md:px-[80px]">
          <h2 className="text-3xl font-serif mb-10 text-center">You May Also Like</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {MOCK_PRODUCTS.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}