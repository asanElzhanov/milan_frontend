import { Link } from "react-router";
import { X, Minus, Plus, ArrowRight } from "lucide-react";
import { MOCK_PRODUCTS } from "../data/mockData";

export function Cart() {
  const cartItems = [
    { product: MOCK_PRODUCTS[0], quantity: 1, size: 38, color: "Black" },
    { product: MOCK_PRODUCTS[1], quantity: 1, size: 39, color: "Brown" },
  ];

  const subtotal = cartItems.reduce((acc, item) => acc + (item.product.salePrice || item.product.price) * item.quantity, 0);

  return (
    <div className="max-w-[1440px] mx-auto w-full px-5 md:px-[80px] py-10 md:py-16 flex-grow">
      <h1 className="text-3xl md:text-5xl font-serif mb-12 text-center">Shopping Bag</h1>

      <div className="flex flex-col lg:flex-row gap-12 lg:gap-20">
        {/* Cart Items */}
        <div className="flex-1">
          <div className="hidden md:grid grid-cols-12 text-xs uppercase tracking-wider text-sara-graphite/50 pb-4 border-b border-sara-beige-dark/20 mb-6">
            <div className="col-span-6">Product</div>
            <div className="col-span-2 text-center">Quantity</div>
            <div className="col-span-3 text-right">Total</div>
            <div className="col-span-1"></div>
          </div>

          <div className="space-y-8">
            {cartItems.map((item, i) => (
              <div key={i} className="flex flex-col md:grid md:grid-cols-12 gap-4 items-center border-b border-sara-beige-dark/10 pb-8 md:pb-6">
                
                {/* Product Info */}
                <div className="col-span-6 w-full flex gap-6">
                  <div className="w-24 h-32 bg-sara-beige flex-shrink-0">
                    <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex flex-col justify-center">
                    <h3 className="font-serif text-lg mb-2">{item.product.name}</h3>
                    <p className="text-sm text-sara-graphite/60 mb-1">Color: {item.color}</p>
                    <p className="text-sm text-sara-graphite/60 mb-2">Size: {item.size}</p>
                    <div className="text-sm md:hidden mb-4">
                      {item.product.salePrice ? (
                        <span className="text-sara-bronze font-medium">${item.product.salePrice}</span>
                      ) : (
                        <span>${item.product.price}</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Quantity */}
                <div className="col-span-2 w-full md:w-auto flex justify-between md:justify-center items-center">
                  <span className="text-sm uppercase tracking-wider md:hidden">Quantity</span>
                  <div className="flex items-center border border-sara-beige-dark/50">
                    <button className="p-2 hover:bg-sara-beige transition-colors"><Minus size={14} /></button>
                    <span className="w-10 text-center text-sm">{item.quantity}</span>
                    <button className="p-2 hover:bg-sara-beige transition-colors"><Plus size={14} /></button>
                  </div>
                </div>

                {/* Total */}
                <div className="col-span-3 w-full md:w-auto flex justify-between md:justify-end items-center">
                   <span className="text-sm uppercase tracking-wider md:hidden">Total</span>
                   <span className="text-lg hidden md:block">${(item.product.salePrice || item.product.price) * item.quantity}</span>
                </div>

                {/* Remove */}
                <div className="col-span-1 w-full md:w-auto flex justify-end">
                  <button className="text-sara-graphite/40 hover:text-sara-graphite transition-colors flex items-center gap-2 text-sm">
                    <span className="md:hidden uppercase tracking-wider">Remove</span>
                    <X size={20} strokeWidth={1.5} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Order Summary */}
        <div className="w-full lg:w-[400px] flex-shrink-0">
          <div className="bg-sara-beige/20 p-8 border border-sara-beige-dark/20">
            <h2 className="font-serif text-2xl mb-6">Order Summary</h2>
            
            <div className="space-y-4 text-sm text-sara-graphite/80 border-b border-sara-beige-dark/20 pb-6 mb-6">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>${subtotal}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping</span>
                <span>Calculated at checkout</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center text-lg font-medium mb-8">
              <span>Total</span>
              <span>${subtotal}</span>
            </div>
            
            <Link to="/checkout" className="w-full bg-sara-graphite text-white py-4 text-sm uppercase tracking-widest hover:bg-black transition-colors flex items-center justify-center gap-2 mb-4">
              Proceed to Checkout <ArrowRight size={16} />
            </Link>
            
            <Link to="/catalog" className="w-full text-center block text-sm uppercase tracking-wider text-sara-graphite/60 hover:text-sara-graphite transition-colors underline-offset-4 hover:underline">
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}