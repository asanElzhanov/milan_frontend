import { useState } from "react";
import { Link } from "react-router";
import { User, Package, Heart, MapPin, CreditCard, LogOut, Gift } from "lucide-react";
import { MOCK_PRODUCTS } from "../data/mockData";
import { ProductCard } from "../components/ProductCard";

export function Account() {
  const [activeTab, setActiveTab] = useState("profile");

  return (
    <div className="max-w-[1440px] mx-auto w-full px-5 md:px-[80px] py-10 md:py-16 flex-grow flex flex-col md:flex-row gap-10 md:gap-16">
      
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 flex-shrink-0">
        <h1 className="text-3xl font-serif mb-8">My Account</h1>
        <nav className="space-y-2">
          {[
            { id: "profile", label: "Profile", icon: User },
            { id: "orders", label: "Orders", icon: Package },
            { id: "favorites", label: "Favorites", icon: Heart },
            { id: "addresses", label: "Addresses", icon: MapPin },
            { id: "bonuses", label: "Loyalty Program", icon: Gift },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-sm transition-colors ${activeTab === item.id ? 'bg-sara-beige font-medium text-sara-graphite' : 'text-sara-graphite/70 hover:bg-sara-beige/50'}`}
            >
              <item.icon size={18} strokeWidth={1.5} />
              {item.label}
            </button>
          ))}
          <button className="w-full flex items-center gap-3 px-4 py-3 text-sm text-red-500/80 hover:bg-red-50 transition-colors mt-8">
            <LogOut size={18} strokeWidth={1.5} />
            Sign Out
          </button>
        </nav>
      </aside>

      {/* Content Area */}
      <div className="flex-1">
        
        {/* Profile Tab */}
        {activeTab === "profile" && (
          <div className="max-w-2xl">
            <h2 className="text-2xl font-serif mb-6">Personal Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div>
                <label className="block text-xs uppercase tracking-wider text-sara-graphite/60 mb-2">First Name</label>
                <input type="text" defaultValue="Sara" className="w-full border border-sara-beige-dark/50 p-3 text-sm focus:border-sara-graphite outline-none" />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wider text-sara-graphite/60 mb-2">Last Name</label>
                <input type="text" defaultValue="Milan" className="w-full border border-sara-beige-dark/50 p-3 text-sm focus:border-sara-graphite outline-none" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-xs uppercase tracking-wider text-sara-graphite/60 mb-2">Email Address</label>
                <input type="email" defaultValue="sara@example.com" className="w-full border border-sara-beige-dark/50 p-3 text-sm focus:border-sara-graphite outline-none" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-xs uppercase tracking-wider text-sara-graphite/60 mb-2">Phone Number (WhatsApp)</label>
                <input type="tel" defaultValue="+7 700 123 4567" className="w-full border border-sara-beige-dark/50 p-3 text-sm focus:border-sara-graphite outline-none" />
              </div>
            </div>
            <button className="bg-sara-graphite text-white px-8 py-3 text-sm uppercase tracking-widest hover:bg-black transition-colors">
              Save Changes
            </button>
          </div>
        )}

        {/* Orders Tab */}
        {activeTab === "orders" && (
          <div>
            <h2 className="text-2xl font-serif mb-6">Order History</h2>
            <div className="space-y-6">
              {[
                { id: "#SM-10492", date: "Oct 24, 2025", status: "Delivered", total: 465 },
                { id: "#SM-10480", date: "Sep 12, 2025", status: "Returned", total: 320 }
              ].map((order, i) => (
                <div key={i} className="border border-sara-beige-dark/20 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-serif text-lg">{order.id}</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${order.status === 'Delivered' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                        {order.status}
                      </span>
                    </div>
                    <p className="text-sm text-sara-graphite/60">{order.date} • ${order.total}</p>
                  </div>
                  <button className="border border-sara-graphite px-6 py-2 text-sm uppercase tracking-widest hover:bg-sara-beige transition-colors">
                    View Details
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Favorites Tab */}
        {activeTab === "favorites" && (
          <div>
            <h2 className="text-2xl font-serif mb-6">Favorites</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
              {MOCK_PRODUCTS.slice(0, 3).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        )}

        {/* Bonuses Tab */}
        {activeTab === "bonuses" && (
          <div>
            <h2 className="text-2xl font-serif mb-6">Sara Milan Privilege</h2>
            <div className="bg-sara-bronze text-white p-8 md:p-12 relative overflow-hidden mb-8">
              <div className="relative z-10">
                <p className="text-sm uppercase tracking-widest mb-2 opacity-80">Current Tier</p>
                <h3 className="text-3xl md:text-4xl font-serif mb-8">Gold Member</h3>
                <div className="flex items-end gap-2 mb-2">
                  <span className="text-5xl font-light">4,250</span>
                  <span className="text-lg opacity-80 pb-1">Points</span>
                </div>
                <p className="text-sm opacity-80">750 points away from Platinum</p>
              </div>
              <div className="absolute right-0 top-0 h-full w-1/2 bg-white/5 skew-x-12 transform origin-top-right"></div>
            </div>
            
            <h3 className="font-serif text-xl mb-4">How it works</h3>
            <p className="text-sm text-sara-graphite/70 leading-relaxed mb-6">
              Earn 1 point for every $1 spent. Redeem points for exclusive discounts, early access to new collections, and special event invitations. This system will be powered by our backend API shortly.
            </p>
          </div>
        )}

        {/* Addresses Tab Placeholder */}
        {activeTab === "addresses" && (
          <div>
            <h2 className="text-2xl font-serif mb-6">Saved Addresses</h2>
            <div className="border border-sara-beige-dark/20 p-6">
              <h3 className="font-serif text-lg mb-2">Default Shipping</h3>
              <p className="text-sm text-sara-graphite/70 mb-1">Sara Milan</p>
              <p className="text-sm text-sara-graphite/70 mb-1">Dostyk Ave 111</p>
              <p className="text-sm text-sara-graphite/70 mb-4">Almaty, 050000, Kazakhstan</p>
              <button className="text-sm uppercase tracking-wider text-sara-bronze hover:text-sara-graphite transition-colors">Edit Address</button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}