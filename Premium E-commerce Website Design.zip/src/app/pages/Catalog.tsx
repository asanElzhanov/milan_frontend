import { useState } from "react";
import { ProductCard } from "../components/ProductCard";
import { MOCK_PRODUCTS } from "../data/mockData";
import { ChevronDown, SlidersHorizontal } from "lucide-react";

export function Catalog() {
  const [showFilters, setShowFilters] = useState(false);
  const categories = ["All", "Boots", "Pumps", "Flats", "Bags", "Accessories"];
  const sizes = ["35", "36", "37", "38", "39", "40", "41"];
  
  return (
    <div className="max-w-[1440px] mx-auto w-full px-5 md:px-[80px] py-10 md:py-16 flex-grow">
      {/* Page Header */}
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-5xl font-serif mb-4">The Collection</h1>
        <p className="text-sara-graphite/60 text-sm">Explore our curated selection of premium footwear and accessories.</p>
      </div>

      {/* Toolbar */}
      <div className="flex justify-between items-center border-y border-sara-beige-dark/20 py-4 mb-10 text-sm">
        <button 
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center gap-2 uppercase tracking-wider hover:text-sara-bronze transition-colors"
        >
          <SlidersHorizontal size={18} />
          <span className="hidden md:inline">Filter</span>
        </button>
        
        <div className="flex items-center gap-2 text-sara-graphite/60">
          <span>{MOCK_PRODUCTS.length} Products</span>
        </div>
        
        <button className="flex items-center gap-2 uppercase tracking-wider hover:text-sara-bronze transition-colors">
          <span>Sort</span>
          <ChevronDown size={16} />
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-10">
        {/* Sidebar Filters */}
        <aside className={`md:w-64 flex-shrink-0 ${showFilters ? 'block' : 'hidden md:block'}`}>
          <div className="space-y-10 sticky top-[120px]">
            <div>
              <h3 className="font-serif text-lg mb-4">Category</h3>
              <ul className="space-y-3 text-sm text-sara-graphite/70">
                {categories.map((cat, i) => (
                  <li key={i}>
                    <button className={`hover:text-sara-bronze transition-colors ${i === 0 ? 'text-sara-graphite font-medium' : ''}`}>
                      {cat}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="font-serif text-lg mb-4">Size</h3>
              <div className="grid grid-cols-4 gap-2">
                {sizes.map((size, i) => (
                  <button 
                    key={i} 
                    className="border border-sara-beige-dark/50 py-2 text-xs hover:border-sara-graphite transition-colors"
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-serif text-lg mb-4">Price</h3>
              <div className="flex items-center gap-4">
                <input type="number" placeholder="Min" className="w-full border border-sara-beige-dark/50 p-2 text-sm bg-transparent outline-none focus:border-sara-graphite" />
                <span>-</span>
                <input type="number" placeholder="Max" className="w-full border border-sara-beige-dark/50 p-2 text-sm bg-transparent outline-none focus:border-sara-graphite" />
              </div>
            </div>
            
            <button className="w-full bg-sara-graphite text-white py-3 text-sm uppercase tracking-widest hover:bg-black transition-colors">
              Apply Filters
            </button>
          </div>
        </aside>

        {/* Product Grid */}
        <div className="flex-1 grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-10 md:gap-x-6 md:gap-y-12">
          {MOCK_PRODUCTS.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
          {/* Duplicate for demo filling */}
          {MOCK_PRODUCTS.map(product => (
            <ProductCard key={product.id + '-dup'} product={{...product, id: product.id + '-dup'}} />
          ))}
        </div>
      </div>
    </div>
  );
}